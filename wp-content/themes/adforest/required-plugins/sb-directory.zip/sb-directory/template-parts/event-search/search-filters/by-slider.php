<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="col-md-4 col-xs-12 col-sm-4">
    <div class="form-group">
       
        <div id="distance-slider"></div>
        <div class="input-group margin-top-10">
            <input type="text" class="form-control" name="min_dis" id="min_dis" value="30" />
            <button  id="submit-distance" class="btn btn-theme btn-default submit-distance" type="button"><span class="fa fa-search"></span></button>
            <input type="hidden"  id="event-lat" name="event-lat" value="">
            <input type="hidden" id= "event-long" name="event-long" value="">
        </div>
        <?php
        ?>   
    </div>
</div>            
